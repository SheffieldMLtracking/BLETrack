/**
 ****************************************************************************************
 *
 * @file user_active_scanner.c
 *
 * @brief Active scanner project source code.
 *
 * Copyright (c) 2012-2021 Renesas Electronics Corporation and/or its affiliates
 * The MIT License (MIT)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
 * OR OTHER DEALINGS IN THE SOFTWARE.
 ****************************************************************************************
 */

/**
 ****************************************************************************************
 * @addtogroup APP
 * @{
 ****************************************************************************************
 */
#include "rwip_config.h"             // SW configuration
#include <stdint.h>
#include "wkupct_quadec.h"
uint8_t receivedPacketsA[2000][6];__SECTION_ZERO("retention_mem_area0");
uint32_t i = 0;__SECTION_ZERO("retention_mem_area0");
uint32_t raw = 0; __SECTION_ZERO("retention_mem_area0");
uint8_t adv_start_delay = 0;__SECTION_ZERO("retention_mem_area0");
bool adv_start_flag = false;__SECTION_ZERO("retention_mem_area0");
uint16_t receivedPacketsIndex = 0;__SECTION_ZERO("retention_mem_area0");
uint16_t sentDataIndex = 0;__SECTION_ZERO("retention_mem_area0");
bool endScanFlag = false;__SECTION_ZERO("retention_mem_area0");
uint32_t startIntervals[3] = {50, 150, 250};__SECTION_ZERO("retention_mem_area0");
uint8_t numIntervals = 3; __SECTION_ZERO("retention_mem_area0");
uint32_t turnOffDelay = 99999;__SECTION_ZERO("retention_mem_area0");
uint32_t rcvPacketIdx;__SECTION_ZERO("retention_mem_area0")
uint16_t total = 0;
uint8_t* data;
uint32_t len;
uint32_t type;
uint8_t* name;
uint8_t manuf_id;

/*
 * INCLUDE FILES
 ****************************************************************************************
 */

#include "user_active_scanner.h"
#include "arch_system.h"
#include "timer1.h"
#include "adc.h"

//New...
#include "rtc.h"

//#include "adc_531.h"

/*
 * FUNCTION DEFINITIONS
 ****************************************************************************************
*/

#define STOP_ADV_IN_SEC    1

 /* Duration of timer for connection parameter update request */
#define APP_PARAM_UPDATE_REQUEST_TO         (1000)   // 1000*10ms = 10sec, The maximum allowed value is 41943sec (4194300 * 10ms)

/* Advertising data update timer */
#define APP_ADV_DATA_UPDATE_TO              (3000)   // 3000*10ms = 30sec, The maximum allowed value is 41943sec (4194300 * 10ms)

/* Manufacturer specific data constants */
#define APP_AD_MSD_COMPANY_ID       (0xABCD)
#define APP_AD_MSD_COMPANY_ID_LEN   (2)
#define APP_AD_MSD_DATA_LEN         (sizeof(uint16_t))

#define APP_PERIPHERAL_CTRL_TIMER_DELAY 100

 timer_hnd app_adv_timeout_timer_used __SECTION_ZERO("retention_mem_area0");

// Manufacturer Specific Data ADV structure type
struct mnf_specific_data_ad_structure
{
    uint8_t ad_structure_size;
    uint8_t ad_structure_type;
    uint8_t company_id[APP_AD_MSD_COMPANY_ID_LEN];
    uint8_t proprietary_data[APP_AD_MSD_DATA_LEN];
};

uint8_t app_connection_idx                      __SECTION_ZERO("retention_mem_area0");
timer_hnd app_adv_data_update_timer_used        __SECTION_ZERO("retention_mem_area0");
timer_hnd app_param_update_request_timer_used   __SECTION_ZERO("retention_mem_area0");

// Retained variables
struct mnf_specific_data_ad_structure mnf_data  __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
// Index of manufacturer data in advertising data or scan response data (when MSB is 1)
uint8_t mnf_data_index                          __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint8_t stored_adv_data_len                     __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint8_t stored_scan_rsp_data_len                __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint8_t stored_adv_data[ADV_DATA_LEN]           __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY
uint8_t stored_scan_rsp_data[SCAN_RSP_DATA_LEN] __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY

struct scan_configuration {
    /// Operation code.
    uint8_t     code;
    /// Own BD address source of the device
    uint8_t     addr_src;
    /// Scan interval
    uint16_t    interval;
    /// Scan window size
    uint16_t    window;
    /// Scanning mode
    uint8_t     mode;
    /// Scan filter policy
    uint8_t     filt_policy;
    /// Scan duplicate filtering policy
    uint8_t     filter_duplic;
};

static const struct scan_configuration user_scan_conf ={
    /// Operation code.
    .code = GAPM_SCAN_PASSIVE,
    /// Own BD address source of the device
    .addr_src = GAPM_CFG_ADDR_PUBLIC,
    /// Scan interval
    .interval = 100, //50 //1176
    /// Scan window size
    .window = 4, //7 //392,
    /// Scanning mode
    .mode = GAP_OBSERVER_MODE,
    /// Scan filter policy
    .filt_policy = SCAN_ALLOW_ADV_ALL,
    /// Scan duplicate filtering policy
    .filter_duplic = SCAN_FILT_DUPLIC_EN
};
/* Generic timer settings */
#define FREE_RUN                        TIM1_FREE_RUN_ON    
#define COUNT_DIRECTION                 TIM1_CNT_DIR_UP
#define RELOAD_VALUE                    TIM1_RELOAD_MAX

/* Generic event Settings */
#define STAMP_TYPE                      TIM1_EVENT_STAMP_CNT        
#define EVENT_PIN                       (tim1_event_gpio_pin_t)(GPIO_SIGNAL_PIN + 1)

/* Define settings for Timer 1 */
#define TIMER1_ON_SYSCLK                1
#define TIMER1_ON_LPCLK                 0

#define INPUT_CLK               TIMER1_ON_LPCLK
#define INTERRUPT_MASK_TMR      TIM1_IRQ_MASK_OFF
#define TIMER1_OVF_COUNTER      1

// Timer1 counting configuration structure
static timer1_count_options_t timer1_config =
{	
	/*Timer1 input clock*/
	.input_clk 	= 	(tim1_clk_src_t)INPUT_CLK,
	
	/*Timer1 free run off*/
	.free_run 	= 	FREE_RUN,
	
	/*Timer1 IRQ mask*/
	.irq_mask	= 	INTERRUPT_MASK_TMR,
	
	/*Timer1 count direction*/
	.count_dir	= 	COUNT_DIRECTION,
	
	/*Timer1 reload value*/
	.reload_val	= 	RELOAD_VALUE
};

uint8_t timer1_cnt_ovf                          __SECTION_ZERO("retention_mem_area0"); //@RETENTION MEMORY

bool isValueInList(uint32_t value, uint32_t list[], uint8_t size) {
    for (int x = 0; x < size; x++) {
        if (list[x] == value) {
            return true; // Value found
        }
    }
    return false; // Value not found
}


static uint16_t read_adc_p0_1(void)
{
    adc_config_t adc_cfg =
    {
        .input_mode      = ADC_INPUT_MODE_SINGLE_ENDED,
        .input           = ADC_INPUT_SE_P0_1,
        .smpl_time_mult  = 2,
        .continuous      = false,
        .interval_mult   = 0,
        .input_attenuator= ADC_INPUT_ATTN_2X, // choose NO / 2X / 3X / 4X per your voltage
        .chopping        = false,
        .oversampling    = 0    // increase for better precision
    };

    // calibrate + init
    adc_offset_calibrate(ADC_INPUT_MODE_SINGLE_ENDED);
    adc_init(&adc_cfg);

    // do one conversion
    adc_start();
    raw = adc_correct_sample(adc_get_sample());
    adc_disable();

    return raw;
}

/**
 ****************************************************************************************
 * @brief Scan function
 * @return void
 ****************************************************************************************
 */
void user_scan_start(void)
{
			struct gapm_start_scan_cmd* cmd = KE_MSG_ALLOC(GAPM_START_SCAN_CMD,
															TASK_GAPM, TASK_APP,
															gapm_start_scan_cmd);

			cmd->op.code = user_scan_conf.code;
			cmd->op.addr_src = user_scan_conf.addr_src;
			cmd->interval = user_scan_conf.interval;
			cmd->window = user_scan_conf.window;
			cmd->mode = user_scan_conf.mode;
			cmd->filt_policy = user_scan_conf.filt_policy;
			cmd->filter_duplic = user_scan_conf.filter_duplic;

			// Send the message
			ke_msg_send(cmd);

			// We are now connectable
			ke_state_set(TASK_APP, APP_CONNECTABLE);
    
		//arch_printf( "SCAN START v2.0\r\n");
}
void scan_stop()
{
	    // Disable Advertising
  struct gapm_cancel_cmd *cmd = app_gapm_cancel_msg_create();
    // Send the message
  app_gapm_cancel_msg_send(cmd);
}

/**
 ****************************************************************************************
 * @brief Scan function
 * @return void
 ****************************************************************************************
 */

// Init manf data
static void mnf_data_init()
{
    mnf_data.ad_structure_size = sizeof(struct mnf_specific_data_ad_structure ) - sizeof(uint8_t); // minus the size of the ad_structure_size field
    mnf_data.ad_structure_type = GAP_AD_TYPE_MANU_SPECIFIC_DATA;
    mnf_data.company_id[0] = APP_AD_MSD_COMPANY_ID & 0xFF; // LSB
    mnf_data.company_id[1] = (APP_AD_MSD_COMPANY_ID >> 8 )& 0xFF; // MSB
    mnf_data.proprietary_data[0] = 0;
    mnf_data.proprietary_data[1] = 0;
}

// Add an AD structure in the Advertising or Scan Response Data of the GAPM_START_ADVERTISE_CMD parameter struct.
static void app_add_ad_struct(struct gapm_start_advertise_cmd *cmd, void *ad_struct_data, uint8_t ad_struct_len, uint8_t adv_connectable)
{
    uint8_t adv_data_max_size = (adv_connectable) ? (ADV_DATA_LEN - 3) : (ADV_DATA_LEN);

    if ((adv_data_max_size - cmd->info.host.adv_data_len) >= ad_struct_len)
    {
        // Append manufacturer data to advertising data
        memcpy(&cmd->info.host.adv_data[cmd->info.host.adv_data_len], ad_struct_data, ad_struct_len);

        // Update Advertising Data Length
        cmd->info.host.adv_data_len += ad_struct_len;

        // Store index of manufacturer data which are included in the advertising data
        mnf_data_index = cmd->info.host.adv_data_len - sizeof(struct mnf_specific_data_ad_structure);
    }
    else if ((SCAN_RSP_DATA_LEN - cmd->info.host.scan_rsp_data_len) >= ad_struct_len)
    {
        // Append manufacturer data to scan response data
        memcpy(&cmd->info.host.scan_rsp_data[cmd->info.host.scan_rsp_data_len], ad_struct_data, ad_struct_len);

        // Update Scan Response Data Length
        cmd->info.host.scan_rsp_data_len += ad_struct_len;

        // Store index of manufacturer data which are included in the scan response data
        mnf_data_index = cmd->info.host.scan_rsp_data_len - sizeof(struct mnf_specific_data_ad_structure);
        // Mark that manufacturer data is in scan response and not advertising data
        mnf_data_index |= 0x80;
    }
    else
    {
        // Manufacturer Specific Data do not fit in either Advertising Data or Scan Response Data
        ASSERT_WARNING(0);
    }
    // Store advertising data length
    stored_adv_data_len = cmd->info.host.adv_data_len;
    // Store advertising data
    memcpy(stored_adv_data, cmd->info.host.adv_data, stored_adv_data_len);
    // Store scan response data length
    stored_scan_rsp_data_len = cmd->info.host.scan_rsp_data_len;
    // Store scan_response data
    memcpy(stored_scan_rsp_data, cmd->info.host.scan_rsp_data, stored_scan_rsp_data_len);
}

static struct gapm_start_advertise_cmd* create_direct_ad_msg(uint8_t ldc_enable)
{
    // Allocate a message for GAP
        struct gapm_start_advertise_cmd* adv_cmd = KE_MSG_ALLOC(GAPM_START_ADVERTISE_CMD,
                                                        TASK_GAPM,
                                                        TASK_APP,
                                                        gapm_start_advertise_cmd);

        if (ldc_enable)
        {
            adv_cmd->op.code = GAPM_ADV_DIRECT_LDC;
            adv_cmd->intv_min = user_adv_conf.intv_min;
            adv_cmd->intv_max = user_adv_conf.intv_max;
        }
        else
        {
            adv_cmd->op.code = GAPM_ADV_DIRECT;
            adv_cmd->intv_min = MS_TO_BLESLOTS(50);
            adv_cmd->intv_max = MS_TO_BLESLOTS(100);
        }
        adv_cmd->op.addr_src = user_adv_conf.addr_src;
        adv_cmd->channel_map = user_adv_conf.channel_map;
				
				// Set peer address to data to send
				if(sentDataIndex >= receivedPacketsIndex)
				{
					sentDataIndex = 0;
				}
				
				if(sentDataIndex < 2000)
				{
					user_adv_conf.peer_addr[0] = receivedPacketsA[sentDataIndex][5];
					//user_adv_conf.peer_addr[0] = sentDataIndex;
					user_adv_conf.peer_addr[1] = receivedPacketsA[sentDataIndex][4];
					user_adv_conf.peer_addr[2] = receivedPacketsA[sentDataIndex][3];
					user_adv_conf.peer_addr[3] = receivedPacketsA[sentDataIndex][2];
					user_adv_conf.peer_addr[4] = receivedPacketsA[sentDataIndex][1];
					user_adv_conf.peer_addr[5] = receivedPacketsA[sentDataIndex][0];
				}
        
				sentDataIndex++;
				
				memcpy(adv_cmd->info.direct.addr.addr, user_adv_conf.peer_addr, BD_ADDR_LEN*sizeof(uint8_t));
        adv_cmd->info.direct.addr_type = user_adv_conf.peer_addr_type;
    return adv_cmd;
}

// cancel ad (used in adv function)
void cancel_ad(void)
{
		if(app_adv_timeout_timer_used != EASY_TIMER_INVALID_TIMER)
		{
			app_adv_timeout_timer_used = EASY_TIMER_INVALID_TIMER;
		}
    struct gapm_cancel_cmd* cmd = KE_MSG_ALLOC(GAPM_CANCEL_CMD,
                                               TASK_GAPM,
                                               TASK_APP,
                                               gapm_cancel_cmd);

    cmd->operation = GAPM_CANCEL;
    ke_msg_send(cmd);
}

void user_app_adv_start(void)
{
	
		//arch_disable_sleep();
    // Schedule the next advertising data update
    //app_adv_data_update_timer_used = app_easy_timer(APP_ADV_DATA_UPDATE_TO, adv_data_update_timer_cb);

    struct gapm_start_advertise_cmd* cmd;
    cmd = create_direct_ad_msg(0);

    // Add manufacturer data to initial advertising or scan response data, if there is enough space
    app_add_ad_struct(cmd, &mnf_data, sizeof(struct mnf_specific_data_ad_structure), 1);
		if(app_adv_timeout_timer_used != EASY_TIMER_INVALID_TIMER)
		{
			app_adv_timeout_timer_used = EASY_TIMER_INVALID_TIMER;
		}
		
		app_adv_timeout_timer_used = app_easy_timer(STOP_ADV_IN_SEC, cancel_ad);
    ke_msg_send(cmd);
		//app_easy_gap_advertise_stop();

    // We are now connectable
    ke_state_set(TASK_APP, APP_CONNECTABLE);
}

// restart adv once a packet is sent
void user_app_on_adv_direct_complete(uint8_t param)
{
		app_adv_timeout_timer_used = app_easy_timer(STOP_ADV_IN_SEC, cancel_ad);
		struct gapm_start_advertise_cmd* cmd;
    cmd = create_direct_ad_msg(0);
    ke_msg_send(cmd);
}

/**
 ****************************************************************************************
 * @brief Timer IR function
 * @return void
 ****************************************************************************************
 */

static void timer1_overflow(void)
{
    if (timer1_cnt_ovf == TIMER1_OVF_COUNTER)
    {
      i++; // If TIMER_OVF_COUNTER = 1 then when i = 7 = 1 second
			//if (isValueInList(i, startIntervals,numIntervals))
			
			//raw = read_adc_p0_1();
			
			// no scan for first 2:22
			//if (i == 7) {
			//	scan_stop();
			//}
			
		/*	if (i==10) {GPIO_SetActive(GPIO_PORT_0, GPIO_PIN_1);}
			if (i==50) {GPIO_SetInactive(GPIO_PORT_0, GPIO_PIN_1);}
			if (i==90) {GPIO_SetActive(GPIO_PORT_0, GPIO_PIN_1);}
			if (i==120) {GPIO_SetInactive(GPIO_PORT_0, GPIO_PIN_1);}
			if (i==150) {GPIO_SetActive(GPIO_PORT_0, GPIO_PIN_1);}
			if (i==180) {GPIO_SetInactive(GPIO_PORT_0, GPIO_PIN_1);}
			if (i==210) {GPIO_SetActive(GPIO_PORT_0, GPIO_PIN_1);}
			if (i==240) {GPIO_SetInactive(GPIO_PORT_0, GPIO_PIN_1);}*/
			
			if (i == 1000) { //<<-- set to 1000 [143s of sleep]; Previously set to 1000
				arch_ble_force_wakeup();
				user_scan_start();
			}
			
				
			// after 15 mins of scanning: stop scanning, wait for interrupt 
			if (i==6460) //<<-- set to 6460 [13 minutes of receiving]; Previously set to 3000 //6300
			{
				arch_ble_force_wakeup();
				scan_stop();
				timer1_stop();
				SetBits16(PMU_CTRL_REG, TIM_SLEEP, 1);
				///////////#######################################################
				///////////#######################################################
				///////////#######################################################
				wkupct_enable_irq(WKUPCT_PIN_SELECT(GPIO_PORT_0, GPIO_PIN_1), // select pin (GPIO_BUTTON_PORT, GPIO_BUTTON_PIN)
									WKUPCT_PIN_POLARITY(GPIO_PORT_0, GPIO_PIN_1, WKUPCT_PIN_POLARITY_HIGH), // polarity high
									1, // 1 event
									63); // debouncing time = 63
			}
			
			//if(i==11000000)
			//{
				//arch_ble_force_wakeup();
				//user_app_adv_start();
				//arch_ble_force_wakeup();
				//user_scan_start();
			//}
			timer1_cnt_ovf = 0;
    }
    timer1_cnt_ovf++;
	
}

void timer1_initialize(void)
{
    /*Enable PD_TIM power domain*/
	SetBits16(PMU_CTRL_REG, TIM_SLEEP, 0);                  // Enable the PD_TIM

	timer1_count_config(&timer1_config, timer1_overflow);   // Set the capture counting configurations for the timer

}

__STATIC_FORCEINLINE void timer1_clear_all_events(void)
{
    SetWord16(TIMER1_CLR_EVENT_REG, TIMER1_CLR_IN1_EVENT | TIMER1_CLR_IN2_EVENT | TIMER1_CLR_TIMER_EVENT);
}

/**
 ****************************************************************************************
 * @brief Init
 * @return void
 ****************************************************************************************
 */

void userGPIOInterruptCallback() 
{
	//scan_stop();
	arch_ble_force_wakeup();
	user_app_adv_start();

}

void setup_rtc(void)
{
	SetBits16(PMU_CTRL_REG, TIM_SLEEP, 0);
	while ((GetWord32(SYS_STAT_REG) & TIM_IS_UP) != TIM_IS_UP);

	/* Put RTC into known state */
	rtc_reset();

	/* Configure the RTC 100Hz clock, based on the LP clock frequency */
	if (arch_clk_is_RCX20()) {
			//extern uint32_t rcx_freq;
		  extern rcx_time_data_t rcx_time_data;

			/* Use the calibrated RCX frequency */
			//rtc_clk_config(RTC_DIV_DENOM_1000, rcx_freq);
		  rtc_clk_config(RTC_DIV_DENOM_1000, rcx_time_data.rcx_freq);
	} else {
			rtc_clk_config(RTC_DIV_DENOM_1024, 32768);
	}
	rtc_clock_enable();

	/* Default RTC configuration */
	static const rtc_config_t cfg_rtc = {
			.hour_clk_mode = RTC_HOUR_MODE_24H,
			.keep_rtc = true,
	};

//	/* Initialize RTC, it will be started when the date and time are set */
//	rtc_init(&cfg_rtc);

//	rtc_time_t time;
//	rtc_calendar_t clndr;
//	rtc_status_code_t status;
//	
//	time.hour = 0;
//	time.minute = 0;
//	time.sec = 0;
//	time.hsec = 0;
//	time.hour_mode = RTC_HOUR_MODE_24H;
//	clndr.year = 1970;
//	clndr.month = 1;
//	clndr.mday = 1;
//	clndr.wday = 1;
//	
//	status = rtc_set_time_clndr(&time, &clndr);
//	arch_printf("\n\rInitialized RTC: 0x%02X", status);
}
void user_app_on_init(void)
{
//	  setup_rtc();
		i = 0;
		GPIO_Disable_HW_Reset();
	  timer1_initialize();
	
    timer1_clear_all_events();
    timer1_enable_irq();
    timer1_start();
	    app_param_update_request_timer_used = EASY_TIMER_INVALID_TIMER;
		app_adv_timeout_timer_used = EASY_TIMER_INVALID_TIMER;
	
	    mnf_data_init();
	
	   // Initialize Advertising and Scan Response Data
    memcpy(stored_adv_data, USER_ADVERTISE_DATA, USER_ADVERTISE_DATA_LEN);
    stored_adv_data_len = USER_ADVERTISE_DATA_LEN;
    memcpy(stored_scan_rsp_data, USER_ADVERTISE_SCAN_RESPONSE_DATA, USER_ADVERTISE_SCAN_RESPONSE_DATA_LEN);
    stored_scan_rsp_data_len = USER_ADVERTISE_SCAN_RESPONSE_DATA_LEN;
		
		//GPIO_set_pad_latch_en(true);
	
				///////////#######################################################
				///////////#######################################################
				///////////#######################################################
		//GPIO_ConfigurePin(GPIO_PORT_0, GPIO_PIN_1, OUTPUT, PID_GPIO, true);
		
		/*while (true) {
		for (uint16_t x=0; x<10000; x++)
		{
		  GPIO_SetActive(GPIO_PORT_0, GPIO_PIN_4);
	  }
		for (uint16_t x=0; x<10000; x++)
		{
		  GPIO_SetInactive(GPIO_PORT_0, GPIO_PIN_4);
	  }
	}*/
	 GPIO_ConfigurePin(GPIO_PORT_0, GPIO_PIN_1, INPUT_PULLDOWN, PID_GPIO, false); //interrupt pin
		//GPIO_ConfigurePin(GPIO_PORT_0, GPIO_PIN_1, OUTPUT, PID_GPIO, true);
		//GPIO_ConfigurePin(GPIO_PORT_0, GPIO_PIN_1, INPUT, PID_ADC, false);
		

		wkupct_register_callback(userGPIOInterruptCallback);
										
		arch_set_sleep_mode(app_default_sleep_mode);
		
}


/**
 ****************************************************************************************
 * @brief Called upon device configuration complete message
 * @return void
 ****************************************************************************************
 */
void user_on_set_dev_config_complete( void )
{
		//user_scan_start();
}

/**
 ****************************************************************************************
 * @brief Scan complete function. Restart the scanning
 * @return void
 ****************************************************************************************
 */
void user_on_scan_complete(const uint8_t param){
    //arch_printf( "SCAN COMPLETE\r\n");
	// CAN ONLY START A TIMER FROM WITHIN HERE IF YOU START SCANNING FIRST - I guess this means
	// you cannot initiate a timer from sleep mode, only do a BLE core wakeup from one.
	// So maybe we set a flag, start scanning, start timer and then immediately use flag to stop scan so that true scanning
	// can start from our timer?????
	// Also appears that you cannot initate scanning from outside a callback? Maybe dependant on sleep mode?
	//  - yes timers dont work when instantiated while BLE core is sleeping
	//  - a timer can initiate scanning (tested so far with a timer started by callback)
	//  - a timer cannot wake up the device from sleep even when intantiated while awake
	// NOTE: app_easy_timer is a timer tied to the BLE core, therefore does not work when core is asleep
	// TRY: using timer 0/1/2
	//new_scan_start();
	//app_easy_timer(1000, test);
	//app_easy_timer(1000, new_scan_start);
}

/**
 ****************************************************************************************
 * @brief Advertising report function. Decode and display most popular advertising field
 * @return void
 ****************************************************************************************
 */
uint32_t count = 0;
uint32_t nDirAdvPackets = 0;

void user_adv_report_ind (struct gapm_adv_report_ind const * param ) {
/* Read time and date from on-chip RTC */
	uint8_t rssi_abs = 256 - param->report.rssi;
	if(param->report.evt_type == ADV_CONN_DIR )
	{
					//arch_printf("Found ADV_DIRECT_IND packet \r\n");
		
		if(((int)param->report.adv_addr.addr[5] == 0xFF) &&
			 ((int)param->report.adv_addr.addr[4] == 0xEA) &&
			 ((int)param->report.adv_addr.addr[3] == 0xCA) &&
			 ((int)param->report.adv_addr.addr[2] == 0x70) &&
			 ((int)param->report.adv_addr.addr[1] == 0x00) &&
			 ((int)param->report.adv_addr.addr[0] == 0x04))
			 {
				//nDirAdvPackets = nDirAdvPackets + 1;
				scan_stop();
				arch_ble_force_wakeup();
				user_app_adv_start();
			 }
		
	}
		//arch_printf("RSSI: -%d ", rssi_abs);
		// report the bluetooth device address
		//arch_printf( "[%02x:%02x:%02x:",  (int)param->report.adv_addr.addr[5], (int)param->report.adv_addr.addr[4], (int)param->report.adv_addr.addr[3] );
		//arch_printf( "%02x:%02x:%02x]\n\r", (int)param->report.adv_addr.addr[2], (int)param->report.adv_addr.addr[1], (int)param->report.adv_addr.addr[0] );
		//arch_printf( "%s", param->report);
		
//		if(receivedPacketsIndex < 2000)
//		{
//			receivedPacketsA[receivedPacketsIndex][0] = rssi_abs;
//			receivedPacketsA[receivedPacketsIndex][1] = (int)param->report.adv_addr.addr[4];
//			receivedPacketsA[receivedPacketsIndex][2] = (int)param->report.adv_addr.addr[3];
//			receivedPacketsA[receivedPacketsIndex][3] = (int)param->report.adv_addr.addr[2];
//			receivedPacketsA[receivedPacketsIndex][4] = (int)param->report.adv_addr.addr[1];
//			receivedPacketsA[receivedPacketsIndex][5] = (int)param->report.adv_addr.addr[0];
//			receivedPacketsIndex = receivedPacketsIndex + 1;
//		}
//	}
		
		/*count = count + 1;
		if (count>100) {
			arch_printf("100 reached!");
			count = 0;
		}*/
		rcvPacketIdx = 0;

	  //while (rcvPacketIdx < param->report.data_len) {
			//data = param->report.data;
			//len = param->report.data[rcvPacketIdx];
			
			uint8_t index = 0;
			uint8_t* tempid;
			name = 0x00;
			manuf_id = 0x4c;
			total = 0x0000;
			while (index < 31)
			{
				uint8_t field_len = param->report.data[index];
				uint8_t field_type = param->report.data[index + 1];
				
				if (field_type == 0x09){
					name = param->report.data + index + 2;
					
					total = 0;	//41,45,5F,	
					for (uint8_t* chr_index=name;chr_index<name+field_len-1;chr_index++)
					{
						total = total + (uint8_t)(*chr_index);
					}
				}
				
				if (field_type == 0xFF){
					tempid = param->report.data + index + 2;
					if ((*tempid == 0x4c) || (*tempid == 0x06) || (*tempid == 0x75))
					{
						manuf_id = 0x06;
					}
					else
					{
						manuf_id = *tempid;
					}
				}
				
				index += field_len + 1;
			}
			
	  //really common devices aren't very useful for tracking,
		//(96% of devices in a quick experiment were Apple, Microsoft or Samsung).
		//0x004c = apple; 0x0006 = microsoft; 0x0075 = samsung.
			// Manufacturer ID: NONE,    zero,    {4c,06,75},    id=something else
			//  Name > 0         4c        0          06              id
			//  Name ==0        return     0        return            id
		
		if ((name == 0x00) && ((manuf_id == 0x4c) || (manuf_id == 0x06))) { 
		return; 
		}
		
		
		
		/*do
		{
			total = total + *name;
			name = name + 2;
		}*/
		//while ((*(name-1) != 0) && (*name != 0));
		//total = 0x88;

		//count = *company_id;
		//total = 0x1234;
		if(receivedPacketsIndex < 2000){
			//rtc_time_t time;
			//rtc_calendar_t clndr;

			/* Read time and date from on-chip RTC */
			//rtc_get_time_clndr(&time, &clndr);

			receivedPacketsA[receivedPacketsIndex][0] = (uint8_t)(i/256); //time.minute;
			receivedPacketsA[receivedPacketsIndex][1] = (uint8_t)(i % 256); //time.sec;
			receivedPacketsA[receivedPacketsIndex][2] = rssi_abs;
			//device name hash
			receivedPacketsA[receivedPacketsIndex][3] = (uint8_t)(total % 256); //todo: could do this with a typecast...
			receivedPacketsA[receivedPacketsIndex][4] = (uint8_t)(total / 256);
			receivedPacketsA[receivedPacketsIndex][5] = (uint8_t)(manuf_id);
			//receivedPacketsA[receivedPacketsIndex][6] = (*company_id)%256;
			receivedPacketsIndex = receivedPacketsIndex + 1;
		}	
		
}



/// @} APP
